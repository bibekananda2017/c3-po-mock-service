var http = require('http');
var request = require('request');

//Local Development
//Enter your Cloudant URL here. Get this from your Bluemix Cloudant service by clicking on "Show Credentials" or "Service Credentials".
var url = "https://9a7ba1f4-6897-4a7e-b63a-56ee4cc76610-bluemix:96d97ddb2247189ca5d271b8f6a6e60b23fa97ba52bd393c2e9846a5ce968232@9a7ba1f4-6897-4a7e-b63a-56ee4cc76610-bluemix.cloudant.com";
var databaseName = "mydb"; //You need to log into Cloudant Dashbaord and create this database

//Running on Bluemix. Gets the Cloudant credentials from VCAP_SERVICES env variable
if(process.env.VCAP_SERVICES){
	var vcap_services = JSON.parse(process.env.VCAP_SERVICES);
	url = vcap_services.cloudantNoSQLDB[0].credentials.url;
}

//Create the database (mydb) if it doesn't exist.
request.put(url + "/" + databaseName).on('error', function(err) {
    console.log("ERROR CREATING DATABSE: " + err);
  })

module.exports = {
  "db": {
	  "connector": "cloudant",
	  "url": url,
	  "database": databaseName
	}
};